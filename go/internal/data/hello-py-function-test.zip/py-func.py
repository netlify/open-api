import json
import time

def handler(event, context):
    metadata = {"version": 1, "builder_function": True}
    return {
        'statusCode': 200,
        'body': json.dumps(time.time()),
        'metadata': metadata
    }